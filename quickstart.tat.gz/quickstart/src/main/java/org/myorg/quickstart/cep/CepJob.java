package org.myorg.quickstart.cep;

import org.apache.flink.api.common.eventtime.WatermarkStrategy;
import org.apache.flink.api.common.functions.FilterFunction;
import org.apache.flink.api.common.serialization.SimpleStringSchema;
import org.apache.flink.api.java.functions.KeySelector;
import org.apache.flink.cep.CEP;
import org.apache.flink.cep.PatternStream;
import org.apache.flink.cep.functions.PatternProcessFunction;
import org.apache.flink.cep.pattern.GroupPattern;
import org.apache.flink.cep.pattern.Pattern;
import org.apache.flink.cep.pattern.conditions.IterativeCondition;
import org.apache.flink.cep.pattern.conditions.SimpleCondition;
import org.apache.flink.connector.elasticsearch.sink.Elasticsearch6SinkBuilder;
import org.apache.flink.connector.kafka.source.KafkaSource;
import org.apache.flink.connector.kafka.source.enumerator.initializer.OffsetsInitializer;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.datastream.KeyedStream;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.apache.flink.util.Collector;
import org.apache.http.HttpHost;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.client.Requests;
import org.myorg.quickstart.cep.condition.ConditionNormal;
import org.myorg.quickstart.cep.condition.ConditionSlow;
import org.myorg.quickstart.cep.model.RowData;
import util.MapUtil;

import java.util.HashMap;
import java.util.Map;

public class CepJob {


    private static final String brokers = "10.19.90.48:12900,10.19.90.49:12900,10.19.90.50:12900,10.19.90.51:12900";
    private static final String topic = "LOG4X-RUM-TOPIC";
    private static final String groupId = "rum-cep-test";

    public static void main(String[] args) throws Exception {
        final StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();

        KafkaSource<String> source = KafkaSource.<String>builder()
                .setBootstrapServers(brokers)
                .setTopics(topic)
                .setGroupId(groupId)
                .setStartingOffsets(OffsetsInitializer.latest())
                .setValueOnlyDeserializer(new SimpleStringSchema()).build();

        DataStreamSource<String> kafkaSource = env.fromSource(source, WatermarkStrategy.noWatermarks(), "kafka source");


//        KeyedStream<Map, String> input =
                kafkaSource
                .flatMap(new RumFlateMap())
                .filter(new FilterFunction<RowData>() {
                    @Override
                    public boolean filter(RowData map) throws Exception {
//                        String s = MapUtil.deepGetString(map, "transaction.type", "");
//                        return s.equals("user-interaction");
                        return true;
                    }
                })
              /*  .keyBy(new KeySelector<Map, String>() {
                    @Override
                    public String getKey(Map map) throws Exception {
                        return MapUtil.deepGetString(map, "extra.page.id", "");
                    }
                })*/
                ;


        /**
         * 页面卡顿规则
         * 同一个页面 不松散连续3次
         * 点击事务时长 > 3秒
         * 1分钟内
         */
        /*Pattern<Map, Map> pattern = Pattern.<Map>begin("start")
                .where(new ConditionSlow())
                .oneOrMore()
                .until(new ConditionNormal())

                .followedBy("middle")
                .where(new ConditionSlow())
                .oneOrMore()
                .until(new ConditionNormal())

                .followedBy("end")
                .where(new ConditionSlow())
                .oneOrMore()
                .until(new ConditionNormal());

        Pattern<Map, Map> until = Pattern
                .begin(pattern)
                .oneOrMore()
                .within(Time.minutes(1));


        PatternStream<Map> patternStream = CEP.pattern(input, until);

        patternStream
                .process(new PatternProcessFunction<Map, Map>() {
                    @Override

                    public void processMatch(Map map, Context context, Collector collector) throws Exception {
                        Map<String, Object> data = new HashMap<>();
                        data.put("logTime", map.get("logTime"));
                        data.put("browserTime", MapUtil.deepGetLongValue(map, "transaction.session", 0L));
                        data.put("sessionId", MapUtil.deepGetStringValue(map, "extra.session.id", ""));
                        data.put("page", MapUtil.deepGetObject(map, "extra.currentPage"));
                        System.out.println("发现一个卡顿页面");
                        collector.collect(map);
                    }
                })
                .sinkTo(
                        new Elasticsearch6SinkBuilder<Map>()
                                .setBulkFlushMaxActions(1)
                                .setHosts(
                                        new HttpHost[]{
                                                new HttpHost("10.19.90.48", 12900),
                                                new HttpHost("10.19.90.49", 12900),
                                                new HttpHost("10.19.90.50", 12900),
                                                new HttpHost("10.19.90.51", 12900),
                                        }
                                )
                                .setEmitter((element, context, indexer) -> {
                                    indexer.add(createIndexRequest(element));
                                })
                                .build()
                )

        ;*/
        env.execute("rum-cep-demo");

    }

    private static IndexRequest createIndexRequest(Map element) {
        Map<String, Object> json = new HashMap<>(1);
        json.put("data", element);
        return Requests.indexRequest()
                .index("log4x_rum_cep_0")
                .type("message")
                .source(json);
    }

}
