package org.myorg.quickstart.cep.condition;

import org.apache.flink.cep.pattern.conditions.IterativeCondition;
import util.MapUtil;

import java.util.Map;

public class ConditionNormal extends IterativeCondition<Map> {
    @Override
    public boolean filter(Map value, Context<Map> ctx) throws Exception {
        Long aLong = MapUtil.deepGetLongValue(value, "transaction.duration", 0L);
        return aLong <= 3000;
    }
}
