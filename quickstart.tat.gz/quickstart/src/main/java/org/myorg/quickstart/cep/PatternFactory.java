package org.myorg.quickstart.cep;

import org.apache.flink.cep.pattern.Pattern;
import org.apache.flink.cep.pattern.conditions.SimpleCondition;
import util.MapUtil;

import java.util.Map;

public class PatternFactory {

    public static void builder(){

    }
}
